
# Azubi Scheduler (full Angular workspace)

## Quick start
```bash
npm install
npm start
```
Then open http://localhost:4200

### What’s included
- Angular 19 standalone app (+ Material, CDK)
- 12×16 year grid with month headers & department rows
- Drag from azubi list to create assignments
- Drag to move (snap to cells), left/right resize (month-snap)
- Remove button on blocks
- Stacking of overlapping azubis in the same dept/month
- Validation to prevent the same azubi overlapping in different departments

Adjust `src/app/app.component.ts` to plug in your real data.
