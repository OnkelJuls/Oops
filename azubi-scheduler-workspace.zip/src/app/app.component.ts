import { Component } from '@angular/core';
import { AzubiYearSchedulerComponent, Azubi, Assignment } from './azubi-year-scheduler.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [AzubiYearSchedulerComponent],
  template: `
    <div style="height: 780px; padding: 16px;">
      <app-azubi-year-scheduler
        [departmentLabels]="departments"
        [years]="years"
        [azubis]="azubis"
        [initialByYear]="seed"
        (assignmentsChange)="onAssignments($event)">
      </app-azubi-year-scheduler>
    </div>
  `
})
export class AppComponent {
  years = [2025, 2026, 2027, 2028];
  departments = [
    'Produktion','Qualität','Einkauf','Vertrieb','IT','HR','Finanzen','Logistik',
    'Planung','Konstruktion','Service','Marketing','F&E','Sicherheit','Recht','Facility'
  ];
  azubis: Azubi[] = Array.from({length:21}, (_,i) => ({
    id: 'z'+i, name: `Azubi ${i+1}`, lehrjahr: ((i%4)+1) as 1|2|3|4
  }));
  seed: Record<number, Assignment[]> = {
    2025: [
      { id:'a1', azubiId:'z0', departmentIndex:0, startMonth:0, spanMonths:4 },
      { id:'a2', azubiId:'z1', departmentIndex:0, startMonth:1, spanMonths:2 },
      { id:'a3', azubiId:'z2', departmentIndex:4, startMonth:6, spanMonths:3 },
    ]
  };

  onAssignments(all: Record<number, Assignment[]>) {
    // Persist to backend if you like
    // console.log('assignments ->', all);
  }
}