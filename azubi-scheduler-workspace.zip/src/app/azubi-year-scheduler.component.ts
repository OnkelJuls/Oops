import {
  AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, EventEmitter,
  Input, Output, ViewChild, computed, effect, inject, signal, NgZone
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragDropModule, CdkDrag, CdkDragEnd } from '@angular/cdk/drag-drop';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

export interface Azubi { id: string; name: string; lehrjahr: 1|2|3|4; }
export interface Assignment {
  id: string;
  azubiId: string;
  departmentIndex: number; // 0..15
  startMonth: number;      // 0..11
  spanMonths: number;      // >=1
}

const MONTHS = ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
const LJ_COLORS: Record<1|2|3|4,string> = {
  1:'#E3F2FD', 2:'#E8F5E9', 3:'#FFF8E1', 4:'#FCE4EC'
};
const clamp = (v:number, lo:number, hi:number) => Math.max(lo, Math.min(hi, v));
const uid = () => Math.random().toString(36).slice(2,9);

// interval overlap on month indices [s, e)
const overlaps = (aS:number, aE:number, bS:number, bE:number) => !(aE <= bS || bE <= aS);

@Component({
  selector: 'app-azubi-year-scheduler',
  standalone: true,
  imports: [CommonModule, DragDropModule, MatSelectModule, MatFormFieldModule, MatSnackBarModule, CdkDrag],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
:host { display:block; height:100%; }
.wrap { position:relative; height:100%; display:flex; flex-direction:column; gap:8px; }
.header { display:flex; align-items:center; gap:12px; }
.gridWrap { position:relative; flex:1 1 auto; min-height:420px; border:1px solid rgba(0,0,0,.08); border-radius:10px; overflow:hidden; }
.canvas { position:absolute; inset:0; z-index:0; display:block; }
.leftRail { position:absolute; left:0; top:24px; bottom:0; width:160px; z-index:1; pointer-events:none; }
.rowLabel { position:absolute; left:8px; width:144px; font:500 12px system-ui; color:rgba(0,0,0,.7);
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis; transform:translateY(-50%); }
.monthHead { position:absolute; top:0; height:24px; font:500 11px system-ui; color:rgba(0,0,0,.7); text-align:center; transform:translateX(-50%); }
.blocks { position:absolute; left:160px; right:0; top:24px; bottom:0; z-index:2; contain:layout paint; }
.block {
  position:absolute; box-sizing:border-box; border-radius:6px; outline:1px solid rgba(0,0,0,.08);
  padding:6px 22px 6px 10px; background:var(--bg); cursor:grab; overflow:hidden; will-change:transform;
}
.block:active { cursor:grabbing; }
.block .title { font:600 12px/1.2 system-ui; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.handle { position:absolute; top:0; bottom:0; width:8px; cursor:ew-resize; touch-action:none; }
.handle.left { left:-3px; } .handle.right { right:-3px; }
.remove {
  position:absolute; right:4px; top:4px; width:18px; height:18px; line-height:16px; text-align:center;
  border-radius:9px; background:rgba(0,0,0,.06); font-weight:700; font-size:12px; cursor:pointer; user-select:none;
}
.remove:hover { background:rgba(0,0,0,.12); }
.legend { margin-left:auto; display:flex; gap:12px; font:11px system-ui; color:rgba(0,0,0,.7); }
.legend .sw { width:10px; height:10px; display:inline-block; border-radius:3px; margin-right:6px; border:1px solid rgba(0,0,0,.12); }
.footer { padding-top:8px; border-top:1px dashed rgba(0,0,0,.12); }
.azubiList { display:flex; flex-wrap:wrap; gap:8px; }
.chip {
  display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:16px;
  background:#fafafa; border:1px solid rgba(0,0,0,.1); user-select:none;
}
.chip[cdkDragDragging] { opacity:.85; }
  `],
  template: `
<div class="wrap">
  <div class="header">
    <mat-form-field appearance="outline">
      <mat-select [value]="year()" (valueChange)="year.set($event)" placeholder="Jahr">
        @for (y of years; track y) { <mat-option [value]="y">{{ y }}</mat-option> }
      </mat-select>
    </mat-form-field>
    <div class="legend">
      <span><span class="sw" [style.background]="LJ_COLORS[1]"></span>LJ 1</span>
      <span><span class="sw" [style.background]="LJ_COLORS[2]"></span>LJ 2</span>
      <span><span class="sw" [style.background]="LJ_COLORS[3]"></span>LJ 3</span>
      <span><span class="sw" [style.background]="LJ_COLORS[4]"></span>LJ 4</span>
    </div>
  </div>

  <div class="gridWrap" #wrap>
    <canvas #canvas class="canvas"></canvas>

    <div class="leftRail">
      @for (label of departmentLabels; track $index) {
        <div class="rowLabel" [style.top.px]="rowTop($index)">{{ label }}</div>
      }
    </div>

    <div class="blocks" #blocks>
      @for (m of monthCenters(); track $index) {
        <div class="monthHead" [style.left.px]="m.x" [style.top.px]="-12">{{ m.label }}</div>
      }

      @for (b of vms(); track b.id) {
        <div class="block"
             [style.left.px]="b.left" [style.top.px]="b.top"
             [style.width.px]="b.width" [style.height.px]="b.height"
             [style.setProperty]="'--bg', b.color"
             cdkDrag
             [cdkDragBoundary]="blocks"
             [cdkDragConstrainPosition]="constrain"
             (cdkDragEnded)="onDragEnd(b, $event)">
          <div class="title">{{ b.label }}</div>
          <div class="remove" title="Entfernen" (click)="removeAssignment(b.id)">×</div>
          <div class="handle left"  (pointerdown)="beginResize($event, b, 'L')"></div>
          <div class="handle right" (pointerdown)="beginResize($event, b, 'R')"></div>
        </div>
      }
    </div>
  </div>

  <div class="footer">
    <div style="font:600 12px system-ui; margin-bottom:6px;">Azubis (ziehen & ablegen auf die Matrix):</div>
    <div class="azubiList">
      @for (a of azubis; track a.id) {
        <div class="chip"
             cdkDrag
             [cdkDragData]="a"
             [cdkDragBoundary]="wrap"
             [cdkDragConstrainPosition]="constrainFromList"
             (cdkDragEnded)="onCreateFromList(a, $event)">
          <span class="dot" [style.background]="LJ_COLORS[a.lehrjahr]" style="width:10px;height:10px;border-radius:50%;border:1px solid rgba(0,0,0,.15)"></span>
          <span>{{ a.name }}</span>
          <small style="opacity:.7;">(LJ {{ a.lehrjahr }})</small>
        </div>
      }
    </div>
  </div>
</div>
  `
})
export class AzubiYearSchedulerComponent implements AfterViewInit {
  @Input({ required: true }) departmentLabels: string[] = [];
  @Input({ required: true }) years: number[] = [];
  @Input({ required: true }) azubis: Azubi[] = [];
  @Input() initialByYear: Record<number, Assignment[]> = {};
  @Output() assignmentsChange = new EventEmitter<Record<number, Assignment[]>>();

  year = signal<number>(new Date().getFullYear());
  assignmentsByYear = signal<Record<number, Assignment[]>>({});

  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('blocks', { static: true }) blocksRef!: ElementRef<HTMLElement>;
  @ViewChild('wrap',   { static: true }) wrapRef!: ElementRef<HTMLElement>;

  private zone = inject(NgZone);
  private snack = inject(MatSnackBar);
  private resizeObs?: ResizeObserver;

  private leftRailW = 160; private headerH = 24;
  colW = signal(80); rowH = signal(40);
  gridW = computed(() => this.colW() * 12);
  gridH = computed(() => this.rowH() * this.departmentLabels.length);

  monthCenters = computed(() => Array.from({length:12}, (_,i) => ({ x: i*this.colW() + this.colW()/2, label: MONTHS[i] })));

  vms = computed(() => {
    const list = (this.assignmentsByYear()[this.year()] ?? []);
    const byDept = new Map<number, Assignment[]>();
    list.forEach(a => {
      if (!byDept.has(a.departmentIndex)) byDept.set(a.departmentIndex, []);
      byDept.get(a.departmentIndex)!.push(a);
    });

    const res: Array<Assignment & { left:number; top:number; width:number; height:number; color:string; label:string; }> = [];
    const colGap = 4; const laneGap = 4;

    for (const [dept, arr] of byDept.entries()) {
      arr.sort((a,b) => a.startMonth - b.startMonth || (a.startMonth + a.spanMonths) - (b.startMonth + b.spanMonths));

      type Active = { end:number; lane:number; id:string };
      const active: Active[] = [];
      const laneOf = new Map<string, number>();
      let laneMax = 0;

      for (const a of arr) {
        const start = a.startMonth, end = a.startMonth + a.spanMonths;
        for (let i = active.length - 1; i >= 0; i--) if (active[i].end <= start) active.splice(i,1);
        const used = new Set(active.map(x => x.lane));
        let lane = 0; while (used.has(lane)) lane++;
        active.push({ end, lane, id: a.id });
        laneOf.set(a.id, lane);
        laneMax = Math.max(laneMax, lane + 1);
      }

      const rowY = this.headerH + dept * this.rowH();
      const laneH = laneMax > 0 ? (this.rowH() - (laneMax + 1) * laneGap) / laneMax : this.rowH();
      arr.forEach(a => {
        const az = this.azubis.find(z => z.id === a.azubiId);
        const color = az ? LJ_COLORS[az.lehrjahr] : '#eee';
        const lane = laneOf.get(a.id) ?? 0;
        const left = a.startMonth * this.colW() + colGap/2;
        const width = a.spanMonths * this.colW() - colGap;
        const top = rowY + laneGap + lane * (laneH + laneGap);
        const height = Math.max(16, laneH);
        res.push({
          ...a, left, width, top, height, color,
          label: az ? `${az.name} — LJ ${az.lehrjahr}` : a.azubiId
        });
      });
    }
    return res;
  });

  ngAfterViewInit(): void {
    this.assignmentsByYear.set(this.initialByYear);

    const recalc = () => {
      const wrap = this.wrapRef.nativeElement;
      const innerW = wrap.clientWidth - this.leftRailW;
      const innerH = wrap.clientHeight - this.headerH;
      const colW = Math.max(56, Math.floor(innerW / 12));
      const rowH = Math.max(30, Math.floor(innerH / Math.max(1, this.departmentLabels.length)));
      this.colW.set(colW);
      this.rowH.set(rowH);
      this.drawGrid();
    };

    this.resizeObs = new ResizeObserver(recalc);
    this.resizeObs.observe(this.wrapRef.nativeElement);
    recalc();

    effect(() => {
      this.colW(); this.rowH(); this.year();
      this.zone.runOutsideAngular(() => this.drawGrid());
    });

    effect(() => {
      this.assignmentsChange.emit(this.assignmentsByYear());
    });
  }

  private drawGrid() {
    const canvas = this.canvasRef.nativeElement;
    const DPR = Math.max(1, window.devicePixelRatio || 1);
    const W = this.leftRailW + this.gridW();
    const H = this.headerH + this.gridH();
    canvas.width = Math.floor(W * DPR);
    canvas.height = Math.floor(H * DPR);
    canvas.style.width = W+'px';
    canvas.style.height= H+'px';
    const ctx = canvas.getContext('2d')!;
    ctx.setTransform(DPR,0,0,DPR,0,0);
    ctx.clearRect(0,0,W,H);

    ctx.fillStyle = '#fff';
    ctx.fillRect(this.leftRailW, 0, this.gridW(), this.headerH);

    for (let m=0;m<12;m++) {
      const x = this.leftRailW + m*this.colW();
      ctx.fillStyle = m%2===0 ? 'rgba(0,0,0,.015)' : 'rgba(0,0,0,.03)';
      ctx.fillRect(x, this.headerH, this.colW(), this.gridH());
      ctx.strokeStyle = 'rgba(0,0,0,.08)';
      ctx.beginPath(); ctx.moveTo(x+0.5, this.headerH); ctx.lineTo(x+0.5, this.headerH+this.gridH()); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(0,0,0,.08)';
    ctx.beginPath(); ctx.moveTo(this.leftRailW + this.gridW()+0.5, this.headerH); ctx.lineTo(this.leftRailW + this.gridW()+0.5, this.headerH+this.gridH()); ctx.stroke();

    for (let r=0;r<this.departmentLabels.length;r++) {
      const y = this.headerH + r*this.rowH();
      ctx.strokeStyle = 'rgba(0,0,0,.08)';
      ctx.beginPath(); ctx.moveTo(this.leftRailW, y+0.5); ctx.lineTo(this.leftRailW+this.gridW(), y+0.5); ctx.stroke();
    }
  }

  rowTop = (row: number) => this.headerH + row*this.rowH();
  LJ_COLORS = LJ_COLORS;

  constrain = (pt: {x:number,y:number}) => {
    const rect = this.blocksRef.nativeElement.getBoundingClientRect();
    let x = clamp(pt.x - rect.left, 0, rect.width);
    let y = clamp(pt.y - rect.top,  0, rect.height);
    const col = clamp(Math.round(x / this.colW()), 0, 12);
    const row = clamp(Math.round(y / this.rowH()), 0, this.departmentLabels.length);
    return { x: rect.left + col * this.colW(), y: rect.top + row * this.rowH() };
  };

  constrainFromList = (pt:{x:number,y:number}) => pt;

  onCreateFromList(azubi: Azubi, ev: CdkDragEnd) {
    const rect = this.blocksRef.nativeElement.getBoundingClientRect();
    const p: any = ev.dropPoint ?? { x: ev.source.getFreeDragPosition().x, y: ev.source.getFreeDragPosition().y };
    if (!p) return;
    if (p.x < rect.left || p.x > rect.right || p.y < rect.top || p.y > rect.bottom) return;

    const localX = p.x - rect.left;
    const localY = p.y - rect.top;
    const startMonth = clamp(Math.floor(localX / this.colW()), 0, 11);
    const dept = clamp(Math.floor(localY / this.rowH()), 0, this.departmentLabels.length - 1);

    const year = this.year();
    const current = { ...this.assignmentsByYear() };
    const list = (current[year] ?? []).slice();
    const newA: Assignment = { id: uid(), azubiId: azubi.id, departmentIndex: dept, startMonth, spanMonths: 1 };

    if (this.wouldOverlap(list, newA, null)) {
      this.snack.open(`${azubi.name} hat bereits einen Einsatz, der diesen Monat überlappt.`, 'OK', { duration: 3000 });
      return;
    }

    list.push(newA);
    current[year] = list;
    this.assignmentsByYear.set(current);
  }

  onDragEnd(vm: Assignment, ev: CdkDragEnd) {
    const el = ev.source.getRootElement() as HTMLElement;
    const left = parseFloat(el.style.left || '0');
    const top  = parseFloat(el.style.top  || '0');
    const startMonth = clamp(Math.round(left / this.colW()), 0, 11);
    const departmentIndex = clamp(Math.round(top / this.rowH()), 0, this.departmentLabels.length - 1);

    const patch: Partial<Assignment> = { startMonth, departmentIndex };
    if (!this.tryPatch(vm.id, patch)) {
      el.style.left = `${vm.startMonth * this.colW()}px`;
      el.style.top  = `${vm.departmentIndex * this.rowH()}px`;
    } else {
      el.style.left = `${startMonth * this.colW()}px";
      el.style.top  = `${departmentIndex * this.rowH()}px`;
    }
  }

  private resizing?: { id:string; dir:'L'|'R'; startX:number; startMonth:number; span:number; };
  beginResize(e: PointerEvent, vm: Assignment, dir:'L'|'R') {
    e.preventDefault();
    const startX = e.clientX;
    this.resizing = { id: vm.id, dir, startX, startMonth: vm.startMonth, span: vm.spanMonths };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);

    const onMove = (pe: PointerEvent) => {
      const dx = pe.clientX - this.resizing!.startX;
      const dCols = Math.round(dx / this.colW());
      let newStart = vm.startMonth;
      let newSpan = vm.spanMonths;

      if (this.resizing!.dir === 'R') {
        newSpan = clamp(this.resizing!.span + dCols, 1, 12 - vm.startMonth);
      } else {
        newStart = clamp(this.resizing!.startMonth + dCols, 0, vm.startMonth + vm.spanMonths - 1);
        const rightEnd = vm.startMonth + vm.spanMonths;
        newSpan = clamp(rightEnd - newStart, 1, 12 - newStart);
      }

      const blockEl = (pe.target as HTMLElement).parentElement as HTMLElement;
      blockEl.style.left = `${newStart * this.colW()}px`;
      blockEl.style.width = `${newSpan * this.colW()}px`;
    };

    const onUp = (pe: PointerEvent) => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      const blockEl = (pe.target as HTMLElement).parentElement as HTMLElement;
      const left = parseFloat(blockEl.style.left);
      const width = parseFloat(blockEl.style.width);
      const startMonth = clamp(Math.round(left / this.colW()), 0, 11);
      const spanMonths = clamp(Math.round(width / this.colW()), 1, 12 - startMonth);

      if (!this.tryPatch(vm.id, { startMonth, spanMonths })) {
        blockEl.style.left = `${vm.startMonth * this.colW()}px`;
        blockEl.style.width = `${vm.spanMonths * this.colW()}px`;
      }

      (pe.currentTarget as HTMLElement).releasePointerCapture(pe.pointerId);
      this.resizing = undefined;
    };

    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerup', onUp, { passive: true });
  }

  removeAssignment(id: string) {
    const cur = { ...this.assignmentsByYear() };
    const y = this.year();
    const list = (cur[y] ?? []).filter(a => a.id !== id);
    cur[y] = list;
    this.assignmentsByYear.set(cur);
  }

  private tryPatch(id: string, patch: Partial<Assignment>): boolean {
    const y = this.year();
    const cur = { ...this.assignmentsByYear() };
    const list = (cur[y] ?? []).slice();
    const i = list.findIndex(a => a.id === id);
    if (i < 0) return false;
    const updated = { ...list[i], ...patch } as Assignment;

    if (this.wouldOverlap(list, updated, id)) {
      const az = this.azubis.find(z => z.id === updated.azubiId);
      this.snack.open(`${az?.name ?? 'Azubi'} hat bereits einen Einsatz, der überlappt.`, 'OK', { duration: 3000 });
      return false;
    }

    list[i] = updated;
    cur[y] = list;
    this.assignmentsByYear.set(cur);
    return true;
  }

  private wouldOverlap(list: Assignment[], candidate: Assignment, ignoreId: string|null) {
    const s = candidate.startMonth;
    const e = candidate.startMonth + candidate.spanMonths;
    return list.some(a =>
      a.azubiId === candidate.azubiId &&
      a.id !== ignoreId &&
      !((e) <= (a.startMonth) || (a.startMonth + a.spanMonths) <= (s))
    );
  }

  getAssignmentsForYear(y: number) { return (this.assignmentsByYear()[y] ?? []).slice(); }
  setAssignmentsForYear(y: number, list: Assignment[]) {
    const cur = { ...this.assignmentsByYear() }; cur[y] = list.slice(); this.assignmentsByYear.set(cur);
  }
}